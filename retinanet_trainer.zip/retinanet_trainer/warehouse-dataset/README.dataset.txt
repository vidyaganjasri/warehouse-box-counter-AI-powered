# Warehouse-Box-Counter > Roboflow Instant 1 [Eval]
https://universe.roboflow.com/warehouse-yby8g/warehouse-box-counter

Provided by a Roboflow user
License: CC BY 4.0

